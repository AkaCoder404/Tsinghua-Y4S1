#include "rip.h"
#include "router.h"
#include "router_hal.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/ip.h>
#include <netinet/ip_icmp.h>
#include <netinet/udp.h>
#include <vector>

extern bool validateIPChecksum(uint8_t *packet, size_t len);
extern void update(bool insert, RoutingTableEntry entry);
extern bool prefix_query(uint32_t addr, uint32_t *nexthop, uint32_t *if_index);
extern bool forward(uint8_t *packet, size_t len);
extern bool disassemble(const uint8_t *packet, uint32_t len, RipPacket *output);
extern uint32_t assemble(const RipPacket *rip, uint8_t *buffer);
extern std::vector<RoutingTableEntry> RoutingTable;
static const in_addr_t MULTICAST_ADDR = 0x090000e0;

uint8_t packet[2048];
uint8_t output[2048];

static const uint32_t masks[64]=
{
  0x00000000,
  0x00000080,
  0x000000c0,
  0x000000e0,
  0x000000f0,
  0x000000f8,
  0x000000fc,
  0x000000fe,
  0x000000ff,
  0x000080ff,
  0x0000c0ff,
  0x0000e0ff,
  0x0000f0ff,
  0x0000f8ff,
  0x0000fcff,
  0x0000feff,
  0x0000ffff,
  0x0080ffff,
  0x00c0ffff,
  0x00e0ffff,
  0x00f0ffff,
  0x00f8ffff,
  0x00fcffff,
  0x00feffff,
  0x00ffffff,
  0x80ffffff,
  0xc0ffffff,
  0xe0ffffff,
  0xf0ffffff,
  0xf8ffffff,
  0xfcffffff,
  0xfeffffff,
  0xffffffff,
};
#define IP_FMT(x) x >> 24, x >> 16 & 0xFF, x >> 8 & 0xFF, x & 0xFF
uint32_t maskToLen(uint32_t mask)
{
  uint32_t Len=0;
  for(uint32_t i=0x80000000; i; i>>=1)
    Len+=(bool)(mask&i);
  return Len;
}
uint16_t assembleIPandUDP(const RipPacket& rip, in_addr_t src, in_addr_t dst, uint8_t* output)
{
  output[0] = 0x45;//version 4, header length 20
  output[1] = 0x00;//TOS: unused
  output[4] = 0xbe;
  output[5] = 0xef;//identification: 0xbeef
  output[6] = 0x00;
  output[7] = 0x00;//flags: 0x0000 do not fragmant
  output[8] = 0x01;//ttl
  output[9] = 0x11;//protocol: 0x11 udp
  *(uint32_t*)(output+12)=src;
  *(uint32_t*)(output+16)=dst;//addresses
  output[20] = 0x02;
  output[21] = 0x08;
  output[22] = 0x02;
  output[23] = 0x08;//port 0x0208
  uint32_t rip_len = assemble(&rip, &output[20 + 8]);
  // checksum calculation for ip and udp
  uint16_t ip_len = 20+8+rip_len;
  *(uint16_t*)(output+2)=htons(ip_len);//ip length
  *(uint16_t*)(output+24)=htons(ip_len-20);//udp length
  output[26]=0;
  output[27]=0;//udp checksum not calculated
  validateIPChecksum(output,ip_len);//ip checksum
  return ip_len;
}

// for online experiment, don't change
// 在线测试用
#ifdef ROUTER_R1
// 0: 192.168.1.1
// 1: 192.168.3.1
// 2: 192.168.6.1
// 3: 192.168.7.1
const in_addr_t addrs[N_IFACE_ON_BOARD] = {0x0101a8c0, 0x0103a8c0, 0x0106a8c0,
                                           0x0107a8c0};
#elif defined(ROUTER_R2)
// 0: 192.168.3.2
// 1: 192.168.4.1
// 2: 192.168.8.1
// 3: 192.168.9.1
const in_addr_t addrs[N_IFACE_ON_BOARD] = {0x0203a8c0, 0x0104a8c0, 0x0108a8c0,
                                           0x0109a8c0};
#elif defined(ROUTER_R3)
// 0: 192.168.4.2
// 1: 192.168.5.2
// 2: 192.168.10.1
// 3: 192.168.11.1
const in_addr_t addrs[N_IFACE_ON_BOARD] = {0x0204a8c0, 0x0205a8c0, 0x010aa8c0,
                                           0x010ba8c0};
#else

// 自己调试用，你可以按需进行修改，注意字节序
// 0: 10.0.0.1
// 1: 10.0.1.1
// 2: 10.0.2.1
// 3: 10.0.3.1
in_addr_t addrs[N_IFACE_ON_BOARD] = {0x0100000a, 0x0101000a, 0x0102000a,
                                     0x0103000a};
#endif

int main(int argc, char *argv[]) 
{
  // 0a.
  int res = HAL_Init(1, addrs);
  if (res < 0) {
    return res;
  }

  // 0b. Add direct routes
  // For example:
  // 10.0.0.0/24 if 0
  // 10.0.1.0/24 if 1
  // 10.0.2.0/24 if 2
  // 10.0.3.0/24 if 3
  for (uint32_t i = 0; i < N_IFACE_ON_BOARD; i++) {
    RoutingTableEntry entry = {
        .addr = addrs[i] & 0x00FFFFFF, // network byte order
        .len = 24,                     // host byte order
        .if_index = i,                 // host byte order
        .nexthop = 0,                  // network byte order, means direct
        .metric = __builtin_bswap32(1)
    };
    update(true, entry);
  }

  macaddr_t MULTICAST_MAC; // 组播MAC
  HAL_ArpGetMacAddress(0, MULTICAST_ADDR, MULTICAST_MAC);

  uint64_t last_time = 0;
  while (1) 
  {
    uint64_t time = HAL_GetTicks();
    // the RFC says 30s interval,
    // but for faster convergence, use 5s here
    // 每五秒在每个端口上组播路由表
    if (time > last_time + 5 * 1000) 
    {
      // ref. RFC 2453 Section 3.8
      printf("5s Timer\n");   // 五秒到了
      // HINT: print complete routing table to stdout/stderr for debugging
      // TODO: send complete routing table to every interface
      for (int i = 0; i < N_IFACE_ON_BOARD; i++) 
      {
        // construct rip response
        // do the mostly same thing as step 3a.3
        // except that dst_ip is RIP multicast IP 224.0.0.9
        // and dst_mac is RIP multicast MAC 01:00:5e:00:00:09
        // 报文结构为IP-UDP-RIP，源地址为当前端口的地址，目的地址为组播地址
        bool Send=false;
        RipPacket Response;
        Response.command = 2;
        Response.numEntries = 0;
        for(auto it = RoutingTable.begin(); it!=RoutingTable.end(); it++)
        {
          if(it->if_index!=i)
          {
            Send=true;
            Response.entries[Response.numEntries].addr = it->addr;
            if(it->len<=32)
              Response.entries[Response.numEntries].mask = masks[it->len];
            else
              Response.entries[Response.numEntries].mask = masks[32];
            Response.entries[Response.numEntries].metric = it->metric;
            Response.entries[Response.numEntries].nexthop = 0;
            Response.numEntries++;
          }
        // 阅读不超过25个条目
          if(Response.numEntries==RIP_MAX_ENTRY)
          {
            Send=false;
            uint32_t ip_len = assembleIPandUDP(Response,addrs[i],MULTICAST_ADDR,output);
            printf("sending rip 5s\n");
            HAL_SendIPPacket(i, output, ip_len, MULTICAST_MAC);
            Response.numEntries=0;
          }
        }
        if(Send)
        {
          uint32_t ip_len = assembleIPandUDP(Response,addrs[i],MULTICAST_ADDR,output);
          printf("sending rip 5s\n");
          HAL_SendIPPacket(i, output, ip_len, MULTICAST_MAC);
        }
      }
      last_time = time;
      // Print Table
      uint32_t size = (uint32_t)RoutingTable.size();
      printf("table: count = %d\n", size);
      for(uint32_t i = size > 20 ? size - 20 : 0; i < size; ++i)
      {
        RoutingTableEntry &e = RoutingTable[i];
        uint32_t addr = __builtin_bswap32(e.addr);
        uint32_t nexthop = __builtin_bswap32(e.nexthop);
        printf("addr: %d.%d.%d.%d, mask: %x, nexthop: %d.%d.%d.%d, metric: %d, if_index: %d\n",
              IP_FMT(addr), 
              __builtin_bswap32((1ULL << RoutingTable[i].len) - 1), 
              IP_FMT(nexthop), 
              __builtin_bswap32(e.metric), 
              e.if_index);
      }
    }

    int mask = (1 << N_IFACE_ON_BOARD) - 1;
    macaddr_t src_mac;
    macaddr_t dst_mac;
    int if_index;
    res = HAL_ReceiveIPPacket(mask, packet, sizeof(packet), src_mac, dst_mac,
                              1000, &if_index);
    if (res == HAL_ERR_EOF) {
      break;
    } else if (res < 0) {
      return res;
    } else if (res == 0) {
      // Timeout
      continue;
    } else if (res > sizeof(packet)) {
      // packet is truncated, ignore it
      continue;
    }

    // 1. validate
    if (!validateIPChecksum(packet, res)) {
      printf("Invalid IP Checksum\n");
      // drop if ip checksum invalid
      continue;
    }
    in_addr_t src_addr, dst_addr;
    // TODO: extract src_addr and dst_addr from packet (big endian)
    // 从数据包（大字节序）中提取src_addr和dst_addr
    src_addr=*(uint32_t*)(packet+12);
    dst_addr=*(uint32_t*)(packet+16);

    // 2. check whether dst is me
    bool dst_is_me = false;
    for (int i = 0; i < N_IFACE_ON_BOARD; i++) {
      if (memcmp(&dst_addr, &addrs[i], sizeof(in_addr_t)) == 0) {
        dst_is_me = true;
        break;
      }
    }
    // TODO: handle rip multicast address(224.0.0.9)
    // TODO: 处理rip多播地址（224.0.0.9）
    if(dst_addr == MULTICAST_ADDR || dst_addr == addrs[0] || dst_addr == addrs[1] || dst_addr == addrs[2] || dst_addr == addrs[3])
    {
      dst_is_me=true;
      dst_addr=addrs[if_index];
    }
    // 判断目的地址是否为自己
    if (dst_is_me) {
      // 3a.1
      RipPacket rip;
      // check and validate
      // 判断是否为RIP包
      if (disassemble(packet, res, &rip)) {
        if (rip.command == 1) {
          // 3a.3 request, ref. RFC 2453 Section 3.9.1
          // only need to respond to whole table requests in the lab
          // 是RIP请求
          // RipPacket resp;
          // TODO: fill resp
          // implement split horizon with poisoned reverse
          // 毒性反转:如果某一条路由表的nexthop就是请求方，那么这条记录的metric应当填为16（即不可达）而非路由表中的数据。
          // // ref. RFC 2453 Section 3.4.3

          // // fill IP headers
          // struct ip *ip_header = (struct ip *)output;
          // ip_header->ip_hl = 5;
          // ip_header->ip_v = 4;
          // // TODO: set tos = 0, id = 0, off = 0, ttl = 1, p = 17(udp), dst and src

          // // fill UDP headers
          // struct udphdr *udpHeader = (struct udphdr *)&output[20];
          // // src port = 520
          // udpHeader->uh_sport = htons(520);
          // // dst port = 520
          // udpHeader->uh_dport = htons(520);
          // // TODO: udp length

          // // assemble RIP
          // uint32_t rip_len = assemble(&resp, &output[20 + 8]);

          // // TODO: checksum calculation for ip and udp
          // // if you don't want to calculate udp checksum, set it to zero

          // // send it back
          // HAL_SendIPPacket(if_index, output, rip_len + 20 + 8, src_mac);
          if(rip.numEntries==1&&rip.entries[0].metric==16)
          {
            RipPacket resp;
            resp.numEntries = 0;
            resp.command = 2;
            bool needSend=false;
            for(auto it = RoutingTable.begin(); it != RoutingTable.end();it++)
            {
              if(it->if_index != if_index)
              {
                resp.entries[resp.numEntries].addr = it->addr;
                if(it->len<=32)
                  resp.entries[resp.numEntries].mask = masks[it->len];
                else
                  resp.entries[resp.numEntries].mask = masks[32];
                  resp.entries[resp.numEntries].metric = it->metric;
                  resp.entries[resp.numEntries].nexthop = 0;
                  resp.numEntries++;
                needSend = true;
              }
            //read no more than 25 entries and send
              if(resp.numEntries==RIP_MAX_ENTRY)
              {
                uint32_t ip_len=assembleIPandUDP(resp,addrs[if_index],src_addr,output);
                printf("sending rip responce\n");
                HAL_SendIPPacket(if_index, output, ip_len, src_mac);
                resp.numEntries=0;
                needSend=false;
              }
            }
            if(needSend)
            {
              uint32_t ip_len=assembleIPandUDP(resp,addrs[if_index],src_addr,output);
              printf("sending rip responce\n");
              HAL_SendIPPacket(if_index, output, ip_len, src_mac);
            }
          }
        } else {
          // 3a.2 response, ref. RFC 2453 Section 3.9.2
          // TODO: update routing table
          // new metric = ?
          // update metric, if_index, nexthop
          // HINT: handle nexthop = 0 case
          // HINT: what is missing from RoutingTableEntry?
          // you might want to use `prefix_query` and `update`, but beware of
          // the difference between exact match and longest prefix match.
          // optional: triggered updates ref. RFC 2453 Section 3.10.1
          // 不是RIP请求，是响应。
          // 根据响应的内容更新自己的路由表
          for(int i=0; i<rip.numEntries; i++)
          {
            RipEntry& rip_entry = rip.entries[i];
            RoutingTableEntry table_entry;
            table_entry.addr = rip_entry.addr;
            table_entry.len = maskToLen(rip_entry.mask);
            table_entry.if_index = if_index;
            table_entry.metric = rip_entry.metric+__builtin_bswap32(1);
            //if(rip_entry.nexthop)
              //table_entry.nexthop=rip_entry.nexthop;
            //else
              table_entry.nexthop=src_addr;
            // 则仅当收到的metric + 1 小于已记录的metric的时候更新路由表。
            if(rip_entry.metric <= __builtin_bswap32(15))
              update(true,table_entry);
          }
          
        }
      } else {
        // not a rip packet
        // handle icmp echo request packet
        // TODO: how to determine?
        // 不是RIP包,判断是否是ICMP Echo包
        struct ip *ip_header = (struct ip *)packet;
        struct icmphdr *icmp_header = (struct icmphdr *)&packet[20];
        if (ip_header->ip_p == 1 && icmp_header->type == ICMP_ECHO) {
          // construct icmp echo reply
          // reply is mostly the same as request,
          // you need to:
          // 1. swap src ip addr and dst ip addr
          // 2. change icmp `type` in header
          // 3. set ttl to 64
          // 4. re-calculate icmp checksum and ip checksum
          // 5. send icmp packet
          // 包的结构为IP-ICMP
          // 源地址为收到的包的端口地址，目的地址为请求方地址。
          // 需要回复的数据一样，所以直接将收到的包memcpy后再更改头数据。
          memcpy(output, packet, res);

          struct ip *ip_header = (struct ip *)output;
          struct icmphdr *icmp_header_output = (struct icmphdr *)&output[20];
          // 交换src ip addr和dst ip addr
          in_addr swap_ip = ip_header->ip_dst;
          ip_header->ip_dst = ip_header->ip_src;
          ip_header->ip_src = swap_ip;
          // ICMP包Type更改
          // Type含义有：8代表Echo Request包，0代表Echo Reply包，11代表TTLE包，3代表Destination Unreachable包
          icmp_header_output->type = 0;
          // 设置TTL为64
          ip_header->ip_ttl = 64;
          // 重新计算IP校验和和ICMP校验和
          validateIPChecksum(output,0);
          
          uint8_t *start = output + ip_header->ip_hl * 4;
          uint8_t *end = output + res; // end of packet
          uint16_t *checksum_loc = (uint16_t *)(start + 2);
          uint32_t checksum_result = 0;
          for(uint16_t *scan = (uint16_t *)start; scan < (uint16_t *)end; scan++) {
              if(scan == checksum_loc) continue;
              checksum_result += *scan;
          }
          checksum_result = (checksum_result & 0xFFFF) + (checksum_result >> 16);
          checksum_result = (checksum_result & 0xFFFF) + (checksum_result >> 16);
          icmp_header_output->checksum = (uint16_t)~checksum_result;
          // 回应对应的Echo Reply包
          printf("sending icmp echo reply\n");
          HAL_SendIPPacket(if_index, output, res, src_mac);
        }
      }
    } else {
      // 3b.1 dst is not me
      // 目的地址不是自己
      // check ttl
      // 判断包是否超时
      uint8_t ttl = packet[8];
      if (ttl <= 1) {
        // send icmp time to live exceeded to src addr
        // fill IP header
        // 向源地址发送TTLE包
        // 包结构为IP-ICMP
        struct ip *ip_header = (struct ip *)output;
        ip_header->ip_hl = 5;
        ip_header->ip_v = 4;
        // TODO: set tos = 0, id = 0, off = 0, ttl = 64, p = 1(icmp), src and dst
        ip_header->ip_tos = 0;
        ip_header->ip_id = 0;
        ip_header->ip_off = 0;
        ip_header->ip_ttl = 64;
        ip_header->ip_p = 1;
        ip_header->ip_dst = in_addr{src_addr};
        ip_header->ip_src = in_addr{addrs[if_index]};



        // fill icmp header
        // ICMP包的内容为收到的包的IP头+IP报文的八个字节
        struct icmphdr *icmp_header = (struct icmphdr *)&output[20];
        // icmp type = Time Exceeded
        icmp_header->type = ICMP_TIME_EXCEEDED;
        // TODO: icmp code = 0
        // TODO: fill unused fields with zero
        // TODO: append "ip header and first 8 bytes of the original payload"
        // TODO: calculate icmp checksum and ip checksum
        // TODO: send icmp packet
        icmp_header->code = 0;
        *(uint32_t *)&output[20+4] = (uint32_t)0;
        // ICMP包的内容为收到的包的IP头+IP报文的八个字节（即前28个字节）。
        memcpy(&output[20+8], packet, 28);
        ip_header->ip_len =  __builtin_bswap16(56); 
        // 重新计算IP校验和和ICMP校验和
        validateIPChecksum(output,0);
        
        uint8_t *start = output + ip_header->ip_hl * 4;
        uint8_t *end = output + 56; 
        uint16_t *checksum_loc = (uint16_t *)(start + 2);
        uint32_t checksum_result = 0;
        for(uint16_t *scan2 = (uint16_t *)start; scan2 < (uint16_t *)end; scan2++) {
            if(scan2 == checksum_loc) continue;
            checksum_result += *scan2;
        }
        checksum_result = (checksum_result & 0xFFFF) + (checksum_result >> 16);
        checksum_result = (checksum_result & 0xFFFF) + (checksum_result >> 16);
        icmp_header->checksum = (uint16_t)~checksum_result;
        // 回应对应的Echo Reply包
        printf("sending icmp time exceeded\n");
        HAL_SendIPPacket(if_index, output, 56, src_mac);
      } else {
        // forward
        // beware of endianness
        // 包没有超时
        uint32_t nexthop, dest_if;
        uint32_t metric;
        nexthop = 0;
        dest_if = 1;
        if (prefix_query(dst_addr, &nexthop, &dest_if)) {
          // found
          // 目的地址可达
          macaddr_t dest_mac;
          // direct routing
          if (nexthop == 0) {
            nexthop = dst_addr;
          }
          if (HAL_ArpGetMacAddress(dest_if, nexthop, dest_mac) == 0) {
            // found
            // memcpy(output, packet, res);

            memcpy(output, packet, res);

            // update ttl and checksum
            //forward(packet, res);// 使用forward函数更新ttl和checksum
            forward(output, res);
            //if (!packet[8])
            //  continue;
            printf("forwarding packet\n");
            HAL_SendIPPacket(dest_if, output, res, dest_mac);
          } else {
            // not found
            // you can drop it
            printf("ARP not found for nexthop %x\n", nexthop);
          }
        } else {
          // 目的地址不可达
          // not found
          // send ICMP Destination Network Unreachable
          printf("IP not found in routing table for src %x dst %x\n", src_addr, dst_addr);
          // send icmp destination net unreachable to src addr
          // fill IP header
          struct ip *ip_header = (struct ip *)output;
          ip_header->ip_hl = 5;
          ip_header->ip_v = 4;
          // TODO: set tos = 0, id = 0, off = 0, ttl = 64, p = 1(icmp), src and dst

          ip_header->ip_tos = 0;
          ip_header->ip_id = 0;
          ip_header->ip_off = 0;
          ip_header->ip_ttl = 64;
          ip_header->ip_p = 1;
          ip_header->ip_dst = in_addr{src_addr};
          ip_header->ip_src = in_addr{addrs[if_index]};

          // fill icmp header
          struct icmphdr *icmp_header = (struct icmphdr *)&output[20];
          // icmp type = Destination Unreachable
          icmp_header->type = ICMP_DEST_UNREACH;
          // TODO: icmp code = Destination Network Unreachable
          // TODO: fill unused fields with zero
          // TODO: append "ip header and first 8 bytes of the original payload"
          // TODO: calculate icmp checksum and ip checksum
          // TODO: send icmp packet
          icmp_header->code = 0;
          *(uint32_t *)&output[20+4] = (uint32_t)0;
          // ICMP包的内容为收到的包的IP头+IP报文的八个字节（即前28个字节）。
          memcpy(&output[20+8], packet, 28);
          ip_header->ip_len =  __builtin_bswap16(56); 
          // 重新计算IP校验和和ICMP校验和
          validateIPChecksum(output,0);
          
          uint8_t *start = output + ip_header->ip_hl * 4;
          uint8_t *end = output + 56; 
          uint16_t *checksum_loc = (uint16_t *)(start + 2);
          uint32_t checksum_result = 0;
          for(uint16_t *scan2 = (uint16_t *)start; scan2 < (uint16_t *)end; scan2++) {
              if(scan2 == checksum_loc) continue;
              checksum_result += *scan2;
          }
          checksum_result = (checksum_result & 0xFFFF) + (checksum_result >> 16);
          checksum_result = (checksum_result & 0xFFFF) + (checksum_result >> 16);
          icmp_header->checksum = (uint16_t)~checksum_result;
          // 回应对应的Echo Reply包
          printf("sending icmp dest unreach\n");
          HAL_SendIPPacket(if_index, output, 56, src_mac);
        }
      }
    }
  }
  return 0;
}
