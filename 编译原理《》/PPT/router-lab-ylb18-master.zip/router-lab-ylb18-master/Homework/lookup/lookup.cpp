#include "router.h"
#include <stdint.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <vector>
#include <algorithm>

/**
 * @brief 插入/删除一条路由表表项
 * @param insert 如果要插入则为 true ，要删除则为 false
 * @param entry 要插入/删除的表项
 *
 * 插入时如果已经存在一条 addr 和 len 都相同的表项，则替换掉原有的。
 * 删除时按照 addr 和 len **精确** 匹配。
 */
std::vector<RoutingTableEntry> RoutingTable;
void update(bool insert, RoutingTableEntry entry) 
{
  for(auto pos=RoutingTable.begin() ; pos!=RoutingTable.end() ; pos++)
  {
    if(pos->addr == entry.addr && pos->len == entry.len)
    {
      if(insert)
      {
        if(entry.metric <= pos->metric)
        {
          *pos = entry;
          return;
        }
        else return;
      }
      else //if(pos != RoutingTable.end())
      {
        RoutingTable.erase(pos);
        return;
      }
    }
  }
  if(insert)
  {
    RoutingTable.push_back(entry);
    return;
  }
}

/**
 * @brief 进行一次路由表的查询，按照最长前缀匹配原则
 * @param addr 需要查询的目标地址，网络字节序
 * @param nexthop 如果查询到目标，把表项的 nexthop 写入
 * @param if_index 如果查询到目标，把表项的 if_index 写入
 * @return 查到则返回 true ，没查到则返回 false
 */
bool prefix_query(uint32_t addr, uint32_t *nexthop, uint32_t *if_index) 
{
  uint32_t len = 0;
  bool found = false;
  // 查询
  for(auto &e : RoutingTable)  
  {
    if(((addr & ((1ULL << e.len) - 1)) == e.addr) && (e.len >= 0))
    {
      // 查询成功后写入nexthop和if_index
      if(len < e.len)
      {
        len = e.len;
        *nexthop = e.nexthop;
        *if_index = e.if_index;
      }
      found = true;
    }
  }
  return found;
}
