#include <stdint.h>
#include <stdlib.h>
/**
 * @brief 进行 IP 头的校验和的验证
 * @param packet 完整的 IP 头和载荷
 * @param len 即 packet 的长度，单位是字节，保证包含完整的 IP 头
 * @return 校验和无误则返回 true ，有误则返回 false
 */
struct IPHeader
{
  uint8_t IHL:4;                //Header长度
  uint8_t Version:4;            //版本
  uint8_t TypeOfService;        //服务类型
  uint16_t TotalLength;         //数据包长度
  uint16_t Identification;      //认证
  uint16_t FragmentOffset;      //段偏移量
  uint8_t TimeToLive;           //生效时间
  uint8_t Protocol;             //协议
  uint16_t HeaderChecksum;      //校验和
  uint32_t SourceAddress;       //源IP地址
  uint32_t DestinationAddress;  //目的IP地址
};
bool validateIPChecksum(uint8_t *packet, size_t len) 
{
  // IPHeader *ip_header = (IPHeader *)packet;
  // uint8_t *start = packet, *end = start + ip_header->IHL * 4;
  // uint32_t checksum = 0;
  // for(uint16_t *p = (uint16_t *)start; p < (uint16_t *)end; p++) 
  // {
  //   if(p == (uint16_t *)(start + 10)) 
  //     continue;
  //   else checksum += *p;
  // }
  // checksum = (checksum & 0xFFFF) + (checksum >> 16);
  // checksum = (checksum & 0xFFFF) + (checksum >> 16);
  // if((uint16_t)~checksum != ip_header->HeaderChecksum) 
  //   return false;
  // else return true;

  // 暂存校验和字段
  int HeaderChecksum = ((int)packet[10] << 8) + (int)packet[11];
  // 校验和字段填充为0
  packet[10] = 0;
  packet[11] = 0;
  // 计算出正确的校验和
  int checksum=0;
  // 将整个分组头视作大端序16位整数的数组，将所有16位整数相加
  for(int i=0; i<((int)packet[0]&0xF)<<2; i+=2)
    checksum += ((int)packet[i]<<8) + (int)packet[i+1];
  // 如果和发生溢出，则将其截断为低16位及溢出部分，然后将溢出部分加到低16位
  while(checksum&0xFFFF0000)
    checksum = (checksum>>16) + (checksum&0xFFFF);
  // HeaderChecksum增量更新
  packet[10] = ~(checksum>>8);
  packet[11] = ~checksum;
  // 校验和的验证
  if(checksum ^ HeaderChecksum ^ 0xFFFF)
    return false;
  else return true;
}