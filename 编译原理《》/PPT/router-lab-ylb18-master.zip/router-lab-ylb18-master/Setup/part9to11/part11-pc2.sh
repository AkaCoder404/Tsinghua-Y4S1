#!/bin/bash
set -v

ping 166.111.4.100
ping 101.6.4.100
