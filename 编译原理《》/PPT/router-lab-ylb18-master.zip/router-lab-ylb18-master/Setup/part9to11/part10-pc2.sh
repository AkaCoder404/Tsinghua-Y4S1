#!/bin/bash
set -v

ping 10.1.2.3
ping 10.8.7.6